<div class="login">
  <div class="login-container"><img alt="Logo login@2x" height="30" src="images/logo-login_2x.png" width="100"/>
    <form>
      <div class="form-group">
        <div class="input-group"><span class="input-group-addon"><i class="icon-envelope"></i></span>
          <input class="form-control" placeholder="Email" type="text"/>
        </div>
      </div>
      <div class="form-group">
        <div class="input-group"><span class="input-group-addon"><i class="icon-lock"></i></span>
          <input class="form-control" placeholder="Password" type="password"/>
        </div>
      </div>
      <div class="form-group">
        <label class="checkbox">
          <input type="checkbox"/>
          Remember me</label>
      </div>
      <div class="btn btn-lg btn-primary login-submit"> Log in </div>
    </form>
    <a href="index.html#">Forgot password?</a></div>
</div>