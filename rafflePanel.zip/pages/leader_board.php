
<div class="col-md-12">
  <div class="widget-container">
    <div class="heading">ATTENDANCE POINT LEADERBOARD</div>
    <div class="widget-content padded">
      <table id="tableData" class="display" cellspacing="0" width="100%">
          <thead>
              <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Company</th>
                  <th>Verification Code</th>
                  <th>Point Total</th>
                  <th>ACTION</th>
              </tr>
          </thead>
        
          <tbody>
              <tr>
                  <td>Tiger Nixon</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td>61</td>
                  <td>2011/04/25</td>
                  <td>2011/04/25</td>
                  <td>$320,800</td>
              </tr>
              <tr>
                  <td>Garrett Winters</td>
                  <td>Accountant</td>
                  <td>Tokyo</td>
                  <td>63</td>
                  <td>2011/07/25</td>
                  <td>2011/07/25</td>
                  <td>$170,750</td>
              </tr>
          </tbody>
      </table>
    </div>

  </div>
</div>